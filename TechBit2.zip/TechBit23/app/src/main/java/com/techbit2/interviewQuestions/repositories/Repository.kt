package com.techbit2.interviewQuestions.repositories

interface Repository {
}