package com.techbit2.articles.repositories

open class Repo {

}